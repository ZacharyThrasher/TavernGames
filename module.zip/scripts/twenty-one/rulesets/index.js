export { submitGoblinRoll } from "./goblin.js";
export { submitStandardRoll } from "./standard.js";
