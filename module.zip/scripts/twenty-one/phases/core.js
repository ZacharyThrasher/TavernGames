import { MODULE_ID, getState, updateState, addHistoryEntry, addLogToAll, addPrivateLog } from "../../state.js"; // V5.8
import { canAffordAnte, deductAnteFromActors, deductFromActor, payOutWinners } from "../../wallet.js";
// import { createChatCard } from "../../ui/chat.js"; // Removed
import { showPublicRoll } from "../../dice.js";

import { tavernSocket } from "../../socket.js";
import { getActorForUser, getActorName, getSafeActorName } from "../utils/actors.js"; // V5.9
import { calculateBettingOrder } from "../utils/game-logic.js";
import { emptyTableData, GOBLIN_STAGE_DICE } from "../constants.js";
import { processSideBetPayouts } from "./side-bets.js";

export async function startRound(startingHeat = 10) {
  const state = getState();
  const ante = game.settings.get(MODULE_ID, "fixedAnte");
  const configuredMode = game.settings.get(MODULE_ID, "gameMode");

  if (!state.turnOrder.length) {
    ui.notifications.warn("No players at the table.");
    return state;
  }

  const affordability = canAffordAnte(state, ante);
  if (!affordability.ok) {
    ui.notifications.warn(`${affordability.name} cannot afford the ${ante}gp ante.`);
    return state;
  }

  await deductAnteFromActors(state, ante);


  const tableData = emptyTableData();
  const gameMode = state.tableData?.gameMode ?? configuredMode ?? "standard";
  tableData.gameMode = gameMode;
  tableData.usedDice = {};

  // V5: Initialize Per-Player Heat
  for (const pid of state.turnOrder) {
    tableData.playerHeat[pid] = startingHeat;
  }

  // Calculate pot: each player antes
  // V3.5: If GM is playing as NPC, no house match (everyone antes equally)
  // If GM is house, house matches non-GM players
  const gmId = state.turnOrder.find(id => game.users.get(id)?.isGM);
  const gmPlayerData = gmId ? state.players?.[gmId] : null;
  const gmIsPlayingAsNpc = gmPlayerData?.playingAsNpc;

  let pot;
  if (gmIsPlayingAsNpc) {
    // GM is a player, no house match - everyone antes equally
    pot = state.turnOrder.length * ante;
  } else {
    // Traditional: non-GM players ante, house matches
    const nonGMPlayers = state.turnOrder.filter(id => !game.users.get(id)?.isGM);
    const playerAntes = nonGMPlayers.length * ante;
    const houseMatch = playerAntes;
    pot = playerAntes + houseMatch;
  }

  if (gameMode === "goblin") {
    tableData.phase = "betting";
    tableData.bettingOrder = [...state.turnOrder];
    tableData.currentPlayer = tableData.bettingOrder[0] ?? null;
    tableData.sideBetRound = 1;
    tableData.sideBetRoundStart = tableData.currentPlayer;
    tableData.theCutPlayer = null;
    tableData.theCutUsed = false;
    tableData.goblinStageIndex = 0;
    tableData.goblinStageDie = GOBLIN_STAGE_DICE[0] ?? 20;
    tableData.goblinStageRemaining = [...tableData.bettingOrder];
    tableData.goblinSuddenDeathActive = false;
    tableData.goblinSuddenDeathParticipants = [];
    tableData.goblinSuddenDeathRemaining = [];
    tableData.goblinBoots = {};
    tableData.goblinHoldStage = {};

    const next = await updateState({
      status: "PLAYING",
      pot,
      tableData,
      turnIndex: 0,
    });

    const playerNames = state.turnOrder.map(id => getActorName(id)).join(", ");
    await addHistoryEntry({
      type: "round_start",
      message: `New Goblin round started. Ante: ${ante}gp each. Pot: ${pot}gp.`,
      players: playerNames,
    });

    await addLogToAll({
      title: "Goblin Rules",
      message: `New round started (Goblin Rules).<br>
        <em>The Chamber shrinks: d20 → d12 → d10 → d8 → d6 → d4 → Coin.<br>
        Roll a 1 and you die. Max roll earns a Boot. Highest survivor wins.</em>`,
      icon: "fa-solid fa-dice",
      type: "phase"
    });

    return next;
  }

  // V3: Auto-roll 2d10 for everyone (1 visible, 1 hole)
  let lowestVisible = Infinity;
  let cutPlayerId = null;

  // Execute rolls in parallel for speed
  const rollPromises = state.turnOrder.map(async (userId) => {
    const roll1 = await new Roll("1d10").evaluate();
    const roll2 = await new Roll("1d10").evaluate();

    // Show dice to player immediately (visible die public, hole die private)
    try {
      // Don't await the socket call to prevent blocking other processing
      tavernSocket.executeAsUser("showRoll", userId, {
        formula: "1d10",
        die: 10,
        result: roll1.total
      });
    } catch (e) {
      console.warn("Tavern Twenty-One | Could not show dice to player:", e);
    }

    return { userId, roll1, roll2 };
  });

  const results = await Promise.all(rollPromises);

  // Process results
  for (const { userId, roll1, roll2 } of results) {
    tableData.rolls[userId] = [
      { die: 10, result: roll1.total, public: true },   // Visible
      { die: 10, result: roll2.total, public: false },  // Hole
    ];
    tableData.totals[userId] = roll1.total + roll2.total;
    tableData.visibleTotals[userId] = roll1.total;

    // Track lowest visible for The Cut
    if (roll1.total < lowestVisible) {
      lowestVisible = roll1.total;
      cutPlayerId = userId;
    }
  }

  // V3: Calculate betting order (sorted by visible total, lowest first)
  tableData.bettingOrder = calculateBettingOrder(state, tableData);

  // V3: Set up The Cut - lowest visible die can re-roll hole
  tableData.theCutPlayer = cutPlayerId;
  tableData.theCutUsed = false;

  // V3: Transition to cut phase if someone gets The Cut, otherwise straight to betting
  if (cutPlayerId && state.turnOrder.length > 1) {
    tableData.phase = "cut";
    tableData.currentPlayer = cutPlayerId;
  } else {
    tableData.phase = "betting";
    tableData.currentPlayer = tableData.bettingOrder.find(id => !tableData.busts[id]) ?? null;
    tableData.sideBetRound = 1;
    tableData.sideBetRoundStart = tableData.currentPlayer;
  }

  const next = await updateState({
    status: "PLAYING",
    pot,
    tableData,
    turnIndex: 0,
  });

  const playerNames = state.turnOrder.map(id => getActorName(id)).join(", "); // V5.9
  await addHistoryEntry({
    type: "round_start",
    message: `New round started. Ante: ${ante}gp each. Pot: ${pot}gp.`,
    players: playerNames,
  });

  // V3: Updated message for auto-roll opening
  const cutPlayerName = cutPlayerId ? getActorName(cutPlayerId) : null;
  const safeCutPlayerName = cutPlayerId ? getSafeActorName(cutPlayerId) : null;
  let chatMessage = `Each player antes ${ante}gp. The house matches. Pot: <strong>${pot}gp</strong><br>` +
    `<em>All hands dealt (2d10 each: 1 visible, 1 hole)</em>`;

  if (cutPlayerId && state.turnOrder.length > 1) {
    chatMessage += `<br><strong>${safeCutPlayerName}</strong> has The Cut (lowest visible: ${lowestVisible})`;
  }

  // V5.8: Log to All
  await addLogToAll({
    title: "New Round!",
    message: chatMessage,
    icon: "fa-solid fa-coins",
    type: "phase"
  }, [], cutPlayerId); // Pass cut player ID for image if relevant, or null. Maybe GM image or icon default?
  // Let's rely on default icon/image if cutPlayerId is null.

  return next;
}

export async function revealDice() {
  const state = getState();
  const tableData = state.tableData ?? emptyTableData();
  const gameMode = tableData.gameMode ?? state.tableData?.gameMode ?? "standard";

  if (gameMode === "goblin") {
    return finishRound();
  }

  // Mark as revealing
  await updateState({ status: "REVEALING" });


  // Show all rolls publicly - launch all dice animations in parallel for speed
  const rollPromises = [];
  for (const oduserId of state.turnOrder) {
    const playerRolls = tableData.rolls[oduserId] ?? [];
    for (const rollData of playerRolls) {
      rollPromises.push((async () => {
        const roll = await new Roll(`1d${rollData.die}`).evaluate();
        // Override the result to show the actual value
        if (roll.terms?.[0]?.results?.[0]) {
          roll.terms[0].results[0].result = rollData.result;
          roll._total = rollData.result;
        }
        await showPublicRoll(roll, oduserId);
      })());
    }
  }

  await Promise.all(rollPromises);
  await new Promise(r => setTimeout(r, 500));

  // V4.8.47: Staredown Cinematic
  tavernSocket.executeForEveryone("showSkillCutIn", "STAREDOWN", null, null);
  await new Promise(r => setTimeout(r, 2500));

  // Now transition to The Staredown
  const accusationCost = Math.floor(state.pot / 2);

  await addLogToAll({
    title: "The Staredown",
    message: `All dice revealed... but can you trust them?<br>
      <strong>Make an Accusation?</strong> (Cost: <strong>${accusationCost}gp</strong>)<br>
      <em>Make a false accusation and forfeit your winnings.</em>`,
    icon: "fa-solid fa-eye",
    type: "phase"
  });

  return updateState({ status: "INSPECTION" });
}

export async function finishRound() {
  const state = getState();
  const tableData = state.tableData ?? emptyTableData();

  await updateState({ status: "REVEALING" });

  // V2.0: Check for fumbled cheaters (physical cheat < 10 = auto-caught)
  const caught = { ...tableData.caught };
  const fumbledCheaterNames = [];
  const fumbledCheaterNamesSafe = [];
  for (const [cheaterId, cheaterData] of Object.entries(tableData.cheaters)) {
    if (caught[cheaterId]) continue; // Already caught
    const cheats = cheaterData.cheats ?? cheaterData.deceptionRolls ?? [];
    for (const cheatRecord of cheats) {
      if (cheatRecord.fumbled) {
        caught[cheaterId] = true;
        const cheaterName = getActorName(cheaterId); // V5.9
        const safeCheaterName = getSafeActorName(cheaterId);
        fumbledCheaterNames.push(cheaterName);
        fumbledCheaterNamesSafe.push(safeCheaterName);
        break;
      }
    }
  }

  if (fumbledCheaterNames.length > 0) {
    await addLogToAll({
      title: "Fumbled!",
      message: `<strong>${fumbledCheaterNamesSafe.join(", ")}</strong> fumbled their cheat and got caught red-handed!`,
      icon: "fa-solid fa-hand-fist",
      type: "cheat",
      cssClass: "failure"
    });
  }

  // V2.0: If an accusation was made, reveal the outcome and handle bounty
  if (tableData.accusation) {
    const { accuserId, targetId, success, cost, bounty } = tableData.accusation;
    const accuserName = getActorName(accuserId);
    const targetName = getActorName(targetId);
    const safeAccuserName = getSafeActorName(accuserId);
    const safeTargetName = getSafeActorName(targetId);

    await new Promise(r => setTimeout(r, 1000));

    if (success) {


      const refund = cost ?? 0;
      const bountyAmount = bounty ?? 0;

      let actualBounty = 0;
      if (bountyAmount > 0) {
        const collected = await deductFromActor(targetId, bountyAmount);
        actualBounty = collected ? bountyAmount : 0;
      }

      const totalReward = refund + actualBounty;
      if (totalReward > 0) {
        await payOutWinners({ [accuserId]: totalReward });
      }

      const bountyMsg = actualBounty > 0 ? `${actualBounty}gp bounty` : "no bounty";

      await addLogToAll({
        title: "Cheater Caught!",
        message: `<strong>${safeAccuserName}</strong> exposed <strong>${safeTargetName}</strong>!<br>
          <em>${safeAccuserName} earns ${totalReward}gp (${refund} refund + ${bountyMsg})</em>`,
        icon: "fa-solid fa-gavel",
        type: "cheat",
        cssClass: "success"
      }, [], accuserId);

      await addHistoryEntry({
        type: "cheat_caught",
        accuser: accuserName,
        caught: targetName,
        reward: totalReward,
        message: `${accuserName} caught ${targetName} cheating and earned ${totalReward}gp!`,
      });
    } else {


      await addLogToAll({
        title: "False Accusation!",
        message: `<strong>${safeAccuserName}</strong> accused <strong>${safeTargetName}</strong> but was WRONG!<br>
          <em>${safeAccuserName} loses their ${cost ?? 0}gp fee.</em>`,
        icon: "fa-solid fa-face-frown",
        type: "cheat",
        cssClass: "failure"
      }, [], accuserId);

      await addHistoryEntry({
        type: "accusation_failed",
        accuser: accuserName,
        target: targetName,
        cost: cost ?? 0,
        message: `${accuserName} falsely accused ${targetName} and loses ${cost ?? 0}gp.`,
      });
    }

    await new Promise(r => setTimeout(r, 500));
  }

  const totals = tableData.totals ?? {};
  const gameMode = tableData.gameMode ?? state.tableData?.gameMode ?? "standard";
  const isGoblinMode = gameMode === "goblin";
  let best = isGoblinMode ? -Infinity : 0;
  state.turnOrder.forEach((id) => {
    if (caught[id]) return;
    if (tableData.busts?.[id]) return;
    if (tableData.folded?.[id]) return;
    const total = totals[id] ?? 0;
    if (isGoblinMode) {
      if (total > best) best = total;
    } else if (total <= 21 && total > best) {
      best = total;
    }
  });

  const winners = state.turnOrder.filter((id) => {
    if (caught[id]) return false;
    if (tableData.folded?.[id]) return false; // V3: Folded players cannot win
    if (tableData.busts?.[id]) return false;
    if (isGoblinMode) {
      return best !== -Infinity && (totals[id] ?? 0) === best;
    }
    return (totals[id] ?? 0) === best && best > 0;
  });

  if (winners.length > 1) {
    if (isGoblinMode) {
      const participants = [...winners];
      const updatedHolds = { ...tableData.holds };
      for (const id of state.turnOrder) {
        if (!participants.includes(id)) updatedHolds[id] = true;
        else delete updatedHolds[id];
      }

      await addLogToAll({
        title: "SUDDEN DEATH",
        message: `<strong>${participants.map(id => getSafeActorName(id)).join(" vs ")}</strong> are tied!<br><em>The coin decides.</em>`,
        icon: "fa-solid fa-bolt",
        type: "phase"
      });

      tavernSocket.executeForEveryone("showSkillCutIn", "SUDDEN_DEATH", participants[0], participants[1]);

      return updateState({
        status: "PLAYING",
        tableData: {
          ...tableData,
          holds: updatedHolds,
          goblinSuddenDeathActive: true,
          goblinSuddenDeathParticipants: participants,
          goblinSuddenDeathRemaining: participants,
          goblinStageRemaining: participants,
          goblinStageDie: 2,
          currentPlayer: participants[0] ?? null
        }
      });
    }

    const duelParticipantNames = winners.map(id => getActorName(id)).join(" vs "); // V5.9
    const duelParticipantNamesSafe = winners.map(id => getSafeActorName(id)).join(" vs ");

    await addLogToAll({
      title: "The Duel!",
      message: `<strong>${duelParticipantNamesSafe}</strong> are TIED!<br>
        <em>One final clash to settle the pot!</em><br>
        <span style="font-size: 0.9em; opacity: 0.8;">Roll 1d20 + 1d4 per Hit taken.</span>`,
      icon: "fa-solid fa-swords",
      type: "phase"
    });

    // V4.8.50: Duel Cinematic (Fixed)
    const [p1, p2] = winners; // Guaranteed to have at least 2
    tavernSocket.executeForEveryone("showSkillCutIn", "DUEL", p1, p2);
    await new Promise(r => setTimeout(r, 3000));

    const duel = {
      active: true,
      participants: [...winners],
      rolls: {},
      pendingRolls: [...winners],
      round: 1,
      pot: state.pot,
    };

    await addHistoryEntry({
      type: "duel_start",
      participants: duelParticipantNames,
      message: `Duel! ${duelParticipantNames} clash for the pot!`,
    });

    return updateState({
      status: "DUEL",
      tableData: { ...tableData, caught, duel },
    });
  }

  // V3.5: Collect cleaning fees BEFORE payout - they go into the pot
  const cleaningFees = tableData.cleaningFees ?? {};
  const cleaningFeeMessages = [];
  let totalCleaningFees = 0;
  for (const [odId, fee] of Object.entries(cleaningFees)) {
    if (fee > 0) {
      await deductFromActor(odId, fee);
      totalCleaningFees += fee;
      const safeUserName = getSafeActorName(odId); // V5.9
      cleaningFeeMessages.push(`${safeUserName}: ${fee}gp`);
    }
  }

  // Add cleaning fees to pot before winner takes it
  const finalPot = state.pot + totalCleaningFees;

  if (cleaningFeeMessages.length > 0) {
    await addLogToAll({
      title: "Cleaning Fees",
      message: `Use a coaster next time!<br>${cleaningFeeMessages.join("<br>")}`,
      icon: "fa-solid fa-broom",
      type: "system"
    });
  }

  if (winners.length === 1) {
    let payout = finalPot;
    if (isGoblinMode) {
      const holdStage = tableData.goblinHoldStage?.[winners[0]];
      if (holdStage && holdStage > 8) {
        payout = Math.floor(finalPot * 0.5);
        await addLogToAll({
          title: "Coward's Tax",
          message: `${getSafeActorName(winners[0])} held early and only claims <strong>${payout}gp</strong>. The House keeps the rest.`,
          icon: "fa-solid fa-land-mine-on",
          type: "system"
        });
      }
    }

    const payouts = { [winners[0]]: payout };
    if (payout > 0) await payOutWinners(payouts);

    // V4.1: Victory Fanfare
    try {
      const victoryPot = isGoblinMode ? payout : finalPot;
      await tavernSocket.executeForEveryone("showVictoryFanfare", winners[0], victoryPot);
    } catch (e) {
      console.warn("Could not show victory fanfare:", e);
    }

    // V4: Process side bet payouts
    const sideBetWinnerIds = await processSideBetPayouts(winners[0]);
    const sideBetWinners = {};
    for (const id of sideBetWinnerIds) sideBetWinners[id] = true;
    tableData.sideBetWinners = sideBetWinners;
  } else if (winners.length === 0) {
    if (isGoblinMode) {
      await addLogToAll({
        title: "Total Wipeout",
        message: "Everyone died. The House keeps the pot.",
        icon: "fa-solid fa-skull",
        type: "system"
      });
    }

    // V4: No winner - side bets lost
    tableData.sideBetWinners = {};
    await processSideBetPayouts(null);
  }

  return updateState({
    status: "PAYOUT",
    pot: 0,
    tableData: { ...tableData, caught },
  });
}

export async function returnToLobby() {
  const state = getState();
  const configuredMode = game.settings.get(MODULE_ID, "gameMode");
  const gameMode = state.tableData?.gameMode ?? configuredMode ?? "standard";
  return updateState({
    status: "LOBBY",
    pot: 0,
    tableData: { ...emptyTableData(), gameMode },
  });
}
