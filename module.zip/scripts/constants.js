/**
 * Legacy constants shim
 * Redirects to the modular constants file
 */
export * from "./twenty-one/constants.js";
