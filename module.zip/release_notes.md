### Features: Private Game Log & Anti-Cheat
- **Game Log System**: Replaced all Chat Cards with a built-in "Private Log" panel in the sidebar.
    - **Public Events** (Rolls, Bumps, Busts) appear for everyone.
    - **Private Events** (Hunch, Cheat results) appear ONLY for you.
    - **Targeted Events**: You now receive specific alerts when Bumped or Goaded.
- **True Blindness**: Players who are in a "Blind State" (from Hunch failure) can no longer open the Cheat Dialog (preventing them from seeing the die value via UI).
